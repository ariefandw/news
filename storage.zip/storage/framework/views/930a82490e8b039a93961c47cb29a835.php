
<?php $__env->startSection('title','Home page'); ?>
<?php $__env->startSection('stylesheet'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h2><?php echo e($news->news_title); ?></h2>
    <i>Dikirim: <?php echo e(date('d/m/Y h:i', strtotime($news->created_at))); ?></i>
    <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="5000">
        <!-- Indicators -->
        <ol class="carousel-indicators">
        <?php $medias = explode('|', $news->news_medias) ?>
        <?php if(isset($medias[0])): ?>
            <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $m = \App\Models\Media::findOrFail($media);
            ?>
            <li data-target="#myCarousel" data-slide-to="<?php echo e($i); ?>" class="<?php echo e($i == 0 ? 'active' : ''); ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </ol>

        <!-- Slides -->
        <div class="carousel-inner">
        <?php $medias = explode('|', $news->news_medias) ?>
        <?php if(isset($medias[0])): ?>
            <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $m = \App\Models\Media::findOrFail($media);
            ?>
            <div class="item <?php echo e($i == 0 ? 'active' : ''); ?>">
                <img src="<?php echo e(Storage::url($m->media_url)); ?>" alt="Image 1">
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right"></span>
        </a>
    </div>

    <div><?php echo $news->news_description; ?></div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arief\source\repos\news\resources\views/frontend/details.blade.php ENDPATH**/ ?>