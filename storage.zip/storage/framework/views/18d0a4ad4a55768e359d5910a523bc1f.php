
<?php $__env->startSection('title', 'News'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .card-body {
            margin-top: 0px !important;
        }

        .page-titles {
            margin-top: 0px !important;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content bgc-grey-100">
        <div id="mainContent">
            <div class="container-fluid">
                <div class="row ">
                    <div class="col-md-5 ">
                        <h4 class="c-grey-900 mT-10 mB-30">News</h4>
                    </div>
                    <div class="col-md-7 text-right">
                        <a href="<?php echo e(url('/admin/news/add/')); ?>" type="button" data-target="#add_and_edit_modal"
                                data-toggle="" data-id="add"
                                class="add_btn btn btn-info">
                            <i class="fa fa-plus-circle"></i> Create New
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="bgc-white bd bdrs-3 p-20 mB-20">
                            <h4 class="c-grey-900 mB-20">All News</h4>
                            <h6 class="c-grey-900 mB-20">You can manage your news post</h6>
                            <table id="dataTable" class="table table-striped table-bordered" cellspacing="0"
                                   width="100%">
                                <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <!-- <th>Language</th> -->
                                    <!-- <th>Category</th> -->
                                    <th>Type</th>
                                    <th>Source</th>
                                    <th>Views</th>
                                    <th>Published</th>
                                    <th>Status</th>
                                    <th style="width: 60px; text-align: center;">Action</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th>ID</th>
                                    <th>Image</th>
                                    <th>Title</th>
                                    <!-- <th>Language</th> -->
                                    <!-- <th>Category</th> -->
                                    <th>Type</th>
                                    <th>Source</th>
                                    <th>Views</th>
                                    <th>Published</th>
                                    <th>Status</th>
                                    <th style="width: 60px; text-align: center;">Action</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                <?php if(isset($news_list[0])): ?> 
                                    <?php $__currentLoopData = $news_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr role="row" class="even">
                                        <td class="sorting_1"><?php echo e($index+1); ?></td>
                                        <td>
                                            <?php if($news->is_rss == 1): ?>
                                                <img 
                                                <?php if(!empty($news->rss_media)): ?> src="<?php echo e($news->rss_media); ?>" 
                                                <?php else: ?> src="<?php echo e(asset('default.jpeg')); ?>"  <?php endif; ?>
                                                    width="100" alt="image">    
                                            <?php else: ?>
                                            <?php
                                            $medias = !empty($news->news_medias) ? explode('|', $news->news_medias) : null;
                                            $m = 'default.jpeg';
                                            if(isset($medias[0]) && !empty($medias[0])){
                                                $m = \App\Models\Media::findOrFail($medias[0])->media_url;
                                            }
                                            ?>
                                                <img src="<?php echo e(asset(Storage::url($m))); ?>" style="height:30px;" alt="image">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($news->news_title); ?></td>
                                        <!-- <td><?php echo e($news->news_lang); ?></td> -->
                                        <!-- <td><?php if(isset($news->categories)): ?> <?php echo e($news->categories->category_name); ?> <?php endif; ?></td> -->
                                        
                                        <td>
                                            <?php if($news->is_rss == 1): ?>
                                                News Feed
                                            <?php else: ?>
                                                Local Staff
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($news->news_provider); ?></td>
                                        <td><?php echo e($news->viewed); ?></td>
                                        <td><?php echo e(date('d/m/Y',strtotime($news->created_at))); ?></td>
                                        
                                        <td><span class="label label-table label-warning">
                                                <?php if(\App\Http\Enum\AllEnum::STATUS_PENDING==$news->status): ?>
                                                    Pending
                                                <?php elseif(\App\Http\Enum\AllEnum::STATUS_ACTIVE==$news->status): ?>
                                                    Published
                                                <?php elseif(\App\Http\Enum\AllEnum::STATUS_INACTIVE==$news->status): ?>
                                                    Draft
                                                <?php endif; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(url('/admin/news/edit/'.$news->id)); ?>" data-toggle="tooltip"
                                               data-original-title="Edit" aria-describedby="tooltip98153">
                                                <i class="fa fa-edit text-info"></i>
                                            </a>

                                            
                                               
                                                
                                            

                                            <a data-toggle="modal" href="#delete_modal_<?php echo e($news->id); ?>"
                                               data-original-title="Delete">&nbsp;&nbsp;<i
                                                        class="fa fa-trash-o text-danger"></i>
                                            </a>

                                            <div id="delete_modal_<?php echo e($news->id); ?>" class="modal fade in">
                                                <div class="modal-dialog modal-confirm">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h4 class="modal-title">Confirmation</h4>
                                                            <button type="button" class="close" data-dismiss="modal"
                                                                    aria-hidden="true">×
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <p>Are you sure you want to delete this item? This
                                                                action
                                                                cannot
                                                                be undone and you will be unable to recover any
                                                                data.</p>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a href="#" class="btn btn-info"
                                                               data-dismiss="modal">Cancel</a>
                                                            <a data-id="<?php echo e(Crypt::encrypt($news->id)); ?>"
                                                               href="<?php echo e(URL::to('/admin/news/delete/'.$news->id)); ?>"
                                                               class="btn btn-danger delete">Yes, delete it!</a>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>




                                
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- /.row -->
    <div class="modal fade" id="add_and_edit_modal" data-backdrop="static" tabindex="-1" role="dialog"
         aria-labelledby="myModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Modal title</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="text-center" id="loading">
                    <div class="rect1"></div>
                    <div class="rect2"></div>
                    <div class="rect3"></div>
                </div>
                <form action="<?php echo e(url('/admin/news/source/add')); ?>" method="POST" id="form_modal"
                      enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body" id="form_modal_body">
                        <div class="row">
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="required">Name</label>
                                    <input type="text" name="tag_title" class="form-control" value="" id="tag_title"
                                           autofocus required>
                                </div>
                            </div>
                            <div class="col-sm-12">
                                <div class="form-group">
                                    <label class="required">Slug</label>
                                    <input type="text" name="tag_slug" class="form-control" value="" id="tag_slug"
                                           autofocus required>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                        <input type="hidden" name="id" id="id">
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        //delete product and remove it from list
        $(document).on('click', '.confirm', function () {
            var news_id = $(this).val();
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            })
            $.ajax({
                type: "GET",
                url: url + '/admin/news/delete/' + news_id,
                success: function (data) {
                    console.log(data);
                    $("#sa-warning" + news_id).remove();
                },
                error: function (data) {
                    console.log('Error:', data);
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arief\source\repos\news\resources\views/admin/news/news.blade.php ENDPATH**/ ?>