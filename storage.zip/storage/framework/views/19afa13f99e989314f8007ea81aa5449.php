
<?php $__env->startSection('title', 'Add New Post'); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('/admin/chosen/bootstrap-chosen.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('/admin/assets/node_modules/summernote/dist/summernote.css')); ?>">
    <style media="screen">
        .check {
            border-color: red !important;
            opacity: .8;
        }

        .media_file {
            height: 100px;
            background-repeat: no-repeat;
            background-position: top center;
            background-size: cover;
        }

        .thumbnail {
            border: 1px solid #000;
            padding: 5px;
            margin-top: 10px;
        }

        .media_list {
            margin: 0;
            padding: 0;
            list-style-type: none;
        }

        .media_list li {
            width: 16.666667%;
            float: left;
            padding: 0 5px;
        }

        .media_list li {
            width: 16.666667%;
            float: left;
            padding: 0 5px;
        }

        .chosen-container {
            width: 100% !important;
        }

        @media (min-width: 992px) {
            .media_list li {
                width: 16.666667%;
                float: left;
            }
        }

        @media (min-width: 768px) {
            .media_list li {
                width: 20%;
                float: left;
            }
        }

        @media (max-width: 767px) {
            .media_list li {
                width: 25%;
                float: left;
            }
        }
    </style>

    <link rel="stylesheet" href="<?php echo e(asset('/admin/chosen/bootstrap-chosen.css')); ?>">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="main-content bgc-grey-100">
        <div id="mainContent">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <form action="<?php echo e(url('/admin/news/save')); ?>" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="form-group">
                                        <label>News Title</label>
                                        <input type="" class="form-control" name="news_title"
                                               value="<?php echo e($news->news_title); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label>News Description</label>
                                        <textarea id="summernote" class="form-control" name="news_description"
                                             rows="10"><p><?php echo $news->news_description; ?></p></textarea>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>News Category</label>
                                                <select class="form-control" name="category_id">
                                                    <option value="">Select Categroy</option>
                                                    <?php if(isset($categories[0])): ?>
                                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Provier</label>
                                                <input type="text" class="form-control" name="news_provider"
                                                       value="<?php echo e($news->news_provider); ?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Language</label>
                                                <?php $langs = \App\Models\Language::where('status', \App\Http\Enum\AllEnum::STATUS_ACTIVE)->get(); ?>
                                                <select name="news_lang" id="news_lang" class="form-control" autofocus
                                                        required>
                                                    <option value="">Select</option>
                                                    <?php if(isset($langs[0])): ?>
                                                        <?php $__currentLoopData = $langs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($lang->language_short_name); ?>"><?php echo e($lang->language_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Posted By</label>
                                                <input type="text" class="form-control" name="news_posted_by"
                                                       value="<?php echo e($news->news_title); ?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <?php $news_tags = explode('|', $news->tag_id); ?>
                                                <label>Tag</label>
                                                <select class="form-control" data-placeholder="Select Tags" multiple
                                                        name="tag_id[]">
                                                    <?php if(isset($tags[0])): ?>
                                                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option <?php if(!empty($news_tags[0]) && in_array($tag,$news_tags)): ?> selected
                                                                    <?php endif; ?> value="<?php echo e($tag->id); ?>"><?php echo e($tag->tag_title); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-3">
                                                <label>Featured</label>
                                                <div class="">
                                                    <input type="checkbox" name="is_featured" id="checkbox_featured"
                                                           <?php if($news->is_featured == 1): ?> checked
                                                           <?php endif; ?> class="filled-in chk-col-light-blue"/>
                                                    <label for="checkbox_featured"></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <button type="button" data-toggle="modal" data-target="#media_modal"
                                                class="btn btn-info"
                                                id="select_media">Select Media
                                        </button>
                                        <div id="all_media">
                                            <?php $medias = explode('|', $news->news_medias) ?>
                                            <?php if(isset($medias[0])): ?>
                                                <?php $__currentLoopData = $medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $m = \App\Models\Media::findOrFail($media);
                                                ?>
                                                    <span class="media-label" style="width: 16.66667%; float: left;"
                                                          id="media_label_'+media_id+'">
                                                <div style="background-image: url('<?php echo e(Storage::url($m->media_url)); ?>'); margin: 0 2%;"
                                                     class="media_file"></div>
                                                <input type="hidden" name="medias[]" value="<?php echo e($media); ?>">
                                                <span onclick="remove_file($media)">&#10005;</span></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="">
                                        <button type="submit" class="btn btn-success pull-right">Submit</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Modal -->
    <div class="modal fade" id="media_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-lg" style="max-width: 90% !important;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                aria-hidden="true">&times;</span></button>

                    <h4 class="modal-title float-left" id="myModalLabel">Choose Media</h4>
                </div>
                <div class="modal-body">
                    <div class="text-center hidden" id="loading"><img src="<?php echo e(asset('admin/loading.gif')); ?>"
                                                                      style="width: 100px;margin-top: 5%;"></div>
                    <div id='file_path'></div>
                    <div class="clearfix"></div>
                    <div id="media_form_html" style="height: 250px;overflow-x: scroll;"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" id="chose_media" data-dismiss="modal">Choose</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <form action="<?php echo e(url('/admin/news/get-media-ajax')); ?>" id="media_form" method="post">
        <?php echo e(csrf_field()); ?>

    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('/admin/chosen/chosen.jquery.js')); ?>"></script>
    <script>
        $(function () {
            $('.chosen-select').chosen();
            $('.chosen-select-deselect').chosen({allow_single_deselect: true});
        });
    </script>
    <script>
        $('#summernote').summernote({
            height: 300, // set editor height
            minHeight: null, // set minimum height of editor
            maxHeight: null, // set maximum height of editor
            focus: false // set focus to editable area after initializing summernote
        });
    </script>
    <script>
        $(document.body).on('click', '#select_media', function (e) {
            // $('#media_form').submit();
            $('#loading').show();
            e.preventDefault();
            $.ajax({
                type: 'GET',
                url: $('#media_form').attr('action'),
                data: $('#form_modal').serialize(),
                dataType: 'json',
                success: function (data) {
                    $('#loading').hide();
                    var medias = data.medias;
                    $('#media_form_html').empty();
                    $('#media_form_html').html(medias);
                }
            });
        })

        function remove_file(id) {
            $('#media_label_' + id).empty();
            $('#media_file_' + id).removeClass('check');
        }


        $(document.body).on('click', '#chose_media', function () {
            // $('#media_modal').modal('hide');
            var all_files = $('#file_path').html();
            $('#all_media').html(all_files);
        });

        $(document.body).on('click', '.img-check', function () {
            var media_id = $(this).data('id');
            var media_file = $(this).data('url');
            $(this).addClass('check');

            var make_html = '<span class="media-label" style="width: 16.66667%; float: left;" id="media_label_' + media_id + '">' +
                '<div style="background-image: url(' + media_file + '); margin: 0 2%;" class="media_file"></div>' +
                '<input type="hidden" name="medias[]" value="' + media_id + '" >' +
                '<span onclick="remove_file(' + media_id + ')">&#10005;</span></span>';

            var div = $('#file_path').html();
            $('#file_path').html(div + make_html + ' ');

        });

        $(document).ready(function () {
            $('#summernote').summernote();
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\arief\source\repos\news\resources\views/admin/news/add-new.blade.php ENDPATH**/ ?>