<?php
$categories = App\Models\Category::orderBy('category_name')->where('category_parent_id',null)->get();
?>

<header class="header header-megamenu">
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <div class="search-bar">
                <input type="search" placeholder="Type search text here...">
                <div class="search-close"><i class="fa fa-times"></i></div>
            </div>
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                <a class="navbar-brand" href="./index.html"><img src="<?php echo e(asset('/frontend')); ?>/img/logo.png" class="img-responsive" alt=""/></a>
            </div>
            <div class="search-trigger pull-right"></div>
            <div class="login pull-right"></div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav">
                    <li class="dropdown dropdown-v1">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <li class="dropdown dropdown-v1">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Category <span
                                        class="fa fa-angle-down"></span></a>
                        <ul class="dropdown-menu">
                            <?php if(!empty($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(route('categoryNews',['id'=>$category->id,'category_slug' => $category->category_slug])); ?>"><?php echo e($category->category_name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    </li>
                    

                    
                    <li class="dropdown megamenu">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Video <span
                                        class="fa fa-angle-down"></span></a>
                        <ul class="dropdown-menu">
                            <li>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="header-post">
                                            <a href="#">
                                                <div class="hp-thumb">
                                                    <img src="<?php echo e(asset('/frontend')); ?>/img/header/1.jpg" class="img-full" alt="" />
                                                </div>
                                            </a>
                                            <date>Sep 25, 2016</date>
                                            <h4><a href="#">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
                                            <p>The list of potential Twitter acquirers continues to grow. In addition to recent
                                                reports that Salesforce and</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="header-post">
                                            <a href="#">
                                                <div class="hp-thumb">
                                                    <div class="hp-overlay">
                                                        <img src="<?php echo e(asset('/frontend')); ?>/img/header/gallery.png" alt="" />
                                                        <span>12 Photos</span>
                                                    </div>
                                                    <img src="<?php echo e(asset('/frontend')); ?>/img/header/2.jpg" class="img-full" alt="" />
                                                </div>
                                            </a>
                                            <date>Sep 25, 2016</date>
                                            <h4><a href="#">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
                                            <p>The list of potential Twitter acquirers continues to grow. In addition to recent
                                                reports that Salesforce and</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="header-post">
                                            <a href="#">
                                                <div class="hp-thumb">
                                                    <img src="<?php echo e(asset('/frontend')); ?>/img/header/3.jpg" class="img-full" alt="" />
                                                </div>
                                            </a>
                                            <date>Sep 25, 2016</date>
                                            <h4><a href="#">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
                                            <p>The list of potential Twitter acquirers continues to grow. In addition to recent
                                                reports that Salesforce and</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="header-post">
                                            <a href="#">
                                                <div class="hp-thumb">
                                                    <img src="<?php echo e(asset('/frontend')); ?>/img/header/4.jpg" class="img-full" alt="" />
                                                </div>
                                            </a>
                                            <date>Sep 25, 2016</date>
                                            <h4><a href="#">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
                                            <p>The list of potential Twitter acquirers continues to grow. In addition to recent
                                                reports that Salesforce and</p>
                                        </div>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="header-post">
                                            <a href="#">
                                                <div class="hp-thumb">
                                                    <div class="hp-overlay">
                                                        <img src="<?php echo e(asset('/frontend')); ?>/img/header/play.png" alt="" />
                                                        <span>15:30</span>
                                                    </div>
                                                    <img src="<?php echo e(asset('/frontend')); ?>/img/header/5.jpg" class="img-full" alt="" />
                                                </div>
                                            </a>
                                            <date>Sep 25, 2016</date>
                                            <h4><a href="#">Twitter Stock Surges On Disney Takeover Rumor</a></h4>
                                            <p>The list of potential Twitter acquirers continues to grow. In addition to recent
                                                reports that Salesforce and</p>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
    </nav>
</header><?php /**PATH C:\Users\arief\source\repos\news\resources\views/frontend/widget/menu.blade.php ENDPATH**/ ?>